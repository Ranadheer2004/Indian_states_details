#include <stdio.h>
#include <string.h>

struct state 
{
    char name[30];
    char capital[30];
    char official_language[40];
    int population;
    int area;
    int sex_ratio;
    float literacy_rate;
};

void read_states(struct state states[], int *num_states);
void sort_states(struct state states[], int num_states);
void print_top_n_states(struct state states[], int n);

int main() 
{
    struct state states[28];
    int num_states = 0;
    
    read_states(states, &num_states);
    sort_states(states, num_states);
    
    int n;
    printf("Enter the value of n: ");
    scanf("%d", &n);
    
    print_top_n_states(states, n);
    
    return 0;
}

void read_states(struct state states[], int *num_states)
{
    FILE *file = fopen("p1.txt", "r");
    if (file == NULL) 
    {
        printf("Error opening file\n");
        return;
    }
    
    while (fscanf(file, "%s %s %s %d %d %d %f", states[*num_states].name, states[*num_states].capital, states[*num_states].official_language, &states[*num_states].population, &states[*num_states].area, &states[*num_states].sex_ratio, &states[*num_states].literacy_rate) == 7) 
    {
        (*num_states)++;
    }
    
    fclose(file);
}

void sort_states(struct state states[], int num_states)
{
	int i,j;
    for ( i = 0; i < num_states; i++)
    {
        for ( j = i + 1; j < num_states; j++)
        {
            if (states[i].area < states[j].area)
            {
                struct state temp = states[i];
                states[i] = states[j];
                states[j] = temp;
            }
        }
    }
}

void print_top_n_states(struct state states[], int n)
{
    printf("Top %d largest states are:\n", n);
    int i;
    for ( i = 0; i < n; i++)
    {
        printf("%s \t %d \n", states[i].name, states[i].area);
    }
}

