#include <stdio.h>
#include <string.h>
struct state 
{
    char name[30];
    char capital[30];
    char official_language[40];
    int population;
    int area;
    int sex_ratio;
    float literacy_rate;
};
int main() 
{
	int i,j;
    FILE *file = fopen("states.txt", "r");
    if (file == NULL) 
	{
        printf("Error opening file\n");
        return 1;
    }
    struct state states[28];
    int num_states = 0;
    while (fscanf(file, "%s %s %s %d %d %d %f", states[num_states].name, states[num_states].capital, states[num_states].official_language, &states[num_states].population, &states[num_states].area, &states[num_states].sex_ratio, &states[num_states].literacy_rate) == 7) 
	{
        num_states++;
    }
    fclose(file);
    int arr_population[28];
    struct arr_states
    {
        char arr_name[30];
    };
    struct arr_states arr_st_name[28];
    int n,a;
    
	for(i=0;i<num_states;i++)
    {
    	arr_population[i]=states[i].population;
    	strcpy(arr_st_name[i].arr_name,states[i].name);
	}
	for(i=0;i<num_states;++i)
	{
		for(j=i+1;j<num_states;++j)
		{
			if(arr_population[i] < arr_population[j])
			{
				a=arr_population[i];
				arr_population[i] = arr_population[j];
				arr_population[j] = a;
				char temp[30];
				strcpy(temp,arr_st_name[i].arr_name);
				strcpy(arr_st_name[i].arr_name,arr_st_name[j].arr_name);
				strcpy(arr_st_name[j].arr_name,temp);
			}
		}
	}
	printf("Enter the value of n : ");
	scanf("%d",&n);
	printf("Top %d most populated states are :\n",n);
	for(i=0 ; i < n ; i++)
	{
		printf("%s \t %d \n",arr_st_name[i].arr_name, arr_population[i]);
	}
	return 0;
}