#include<stdio.h>
#include<stdlib.h>
struct truns{
	int runs;
};
int main(){
	struct truns s[10];
	int sum=0,i;
	printf("\n\t enter the runs scored in each innings = ");
	for(i=0;i<10;i++)
	{
	scanf("%d",&s[i].runs);
	sum+=s[i].runs;	
	}
	printf("\n\t total runs=%d",sum);
	return 0;
}
