#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "functions.c"

int main() {
    int i;
    FILE *fp = fopen("p1.txt", "r");
    if (fp == NULL) 
	{
        printf("Error opening file\n");
        return 1;
    }
    struct state states[28];
    int n=0;
    while (fscanf(fp, "%s %s %s %d %d %d %f", states[n].name, states[n].capital,
                  states[n].official_language, &states[n].population,
                  &states[n].area, &states[n].sex_ratio,
                  &states[n].literacy_rate) == 7) {
        n++;
    }
    fclose(fp);
    int input_category, exit = 0;
    char input_type;
    char sort_order;
    bool first_input = true;
    while (!exit) {
        printf("\n");
        printf("Select any of the below options:\n");
        printf("1. To know the Capital cities of all states:\n");
        printf("2. To know the Official languages of all states:\n");
        printf("3. To know the Literacy rate of all states:\n");
        printf("4. To know the Area (sq.km) of all states:\n");
        printf("5. To know the Sex ratio (No.of females/1000 males) of all states:\n");
        printf("6. To know the Population of the states:\n");
        printf("7. To EXIT the program:\n");
        printf("======================================================================= \n");
        scanf("%d", &input_category);
        if (!first_input) {
            clear_screen();
        }
        first_input = false;
        switch (input_category) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                printf("a. Specific state:\n");
                printf("b. Every state:\n");
                printf("c. Sort states:\n");
                printf("=======================================================================\n");
                scanf(" %c", &input_type);
                switch (input_type) {
                    case 'a':
                    case 'b':
                        display_information(states, n, input_type, input_category, sort_order);
                        break;
                    case 'c':
                        printf("Ascending or Descending? (a/d):\n");
                        scanf(" %c", &sort_order);
                        display_information(states, n, input_type, input_category, sort_order);
                        break;
                    default:
                        printf("Invalid option\n");
                        break;
                }
                break;
            case 7:
                printf("Exiting the program.\n");
                exit = 1;
                break;
            default:
                printf("Invalid category\n");
                break;
        }
    }
    return 0;
}

