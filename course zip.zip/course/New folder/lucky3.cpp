\
#include <stdio.h>
#include <stdlib.h>
int main() {
 int size, i;
 int* array;
 int largest;
 printf("Enter the size of the array: ");
 scanf("%d", &size);
 array = (int*)malloc(size * sizeof(int));
 if (array == NULL) {
 printf("Memory allocation failed.\n");
 return 1;
 }
 printf("Enter the elements:\n");
 for (i = 0; i < size; i++) {
 scanf("%d", &array[i]);
 }
 printf("The elements are:\n");
 for (i = 0; i < size; i++) {
 printf("%d ",&array[i]);
 }
 largest = array[0];
 for (i = 1; i < size; i++) {
 if (array[i] > largest) {
 largest = array[i];
 }
 }
 printf("The largest number is: %d\n", largest);
 free(array);
 return 0;
}
