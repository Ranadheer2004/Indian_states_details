#include<stdio.h>
#include<stdlib.h>
struct student{
	int year;
};
int main(){
	struct student s;
	int age,year;
	printf("\n\t enter the birth year = ");
	scanf("%d",&s.year);
	printf("\n\t enter the present year = ");
	scanf("%d",&year);
	age=year-s.year;
	printf("\n\t age=\n%d",age);
	if(age>(15))
	{+
		printf("eligible for aplly\t");
	}
		else{
		printf(" not eligible for aplly\t");
	
	}
	return 0;
}
