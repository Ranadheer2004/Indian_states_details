#include <stdio.h>
#include <string.h>
#include "functions.c"


int main() {
    int i;
    FILE *file = fopen("p1.txt", "r");
    if (file == NULL) {
        printf("Error opening file\n");
        return 1;
    }
    struct state states[28];
    int num_states = 0;
    while (fscanf(file, "%s %s %s %d %d %d %f", states[num_states].name, states[num_states].capital, states[num_states].official_language, &states[num_states].population, &states[num_states].area, &states[num_states].sex_ratio, &states[num_states].literacy_rate) == 7) {
        num_states++;
    }
    fclose(file);
    int input_category;
    char input_type;
    printf("Select any of the below option : \n");
    printf("1. To know the Capital cities of all states :\n");
    printf("2. To know the Official languages of all states :\n");
    printf("3. To know the Literacy rate of all states :\n");
    printf("4. To know the of Area(sq.km) all states :\n");
    printf("5. To know the Sex ratio(No.of females/1000 males) of all states :\n");
    printf("6. To know the Population of the states :\n");
    scanf("%d", &input_category);
    switch (input_category) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            printf("a.Specific state:\n");
            printf("b.Every state:\n");
            scanf(" %c", &input_type);
            display_information(states, num_states, input_type, input_category);
            break;
        default:
            printf("Invalid category\n");
            break;
    }
    return 0;
}

