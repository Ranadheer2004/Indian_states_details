#include <string.h>

struct state {
    char name[30];
    char capital[30];
    char official_language[40];
    int population;
    int area;
    int sex_ratio;
    float literacy_rate;
};
int i,j;
int find_state(struct state states[], int num_states, char state_name[]) {
    for ( i = 0; i < num_states; i++) {
        if (strcmp(states[i].name, state_name) == 0) {
            return i;
        }
    }
    return -1;
}
void display_information(struct state states[], int num_states, char input_type, int input_category, char sort_order) {
    if (input_type == 'a') {
        char input_state[30];
        printf("Enter state: ");
        scanf("%s", input_state);
        int index = find_state(states, num_states, input_state);
        if (index != -1) {
            switch (input_category) {
                case 1:
                    printf("%s\n", states[index].capital);
                    break;
                case 2:
                    printf("%s\n", states[index].official_language);
                    break;
                case 3:
                    printf("%f\n", states[index].literacy_rate);
                    break;
                case 4:
                    printf("%d\n", states[index].area);
                    break;
                case 5:
                    printf("%d\n", states[index].sex_ratio);
                    break;
                case 6:
                    printf("%d\n", states[index].population);
                    break;
            }
        } else {
            printf("State not found\n");
        }
    } else if (input_type == 'b') {
        for ( i = 0; i < num_states; i++) {
            switch (input_category) {
                case 1:
                    printf("%s \t\t %s \n", states[i].name, states[i].capital);
                    break;
                case 2:
                    printf("%s \t\t %s \n", states[i].name, states[i].official_language);
                    break;
                case 3:
                    printf("%s \t\t %f \n", states[i].name, states[i].literacy_rate);
                    break;
                case 4:
                    printf("%s \t\t %d \n", states[i].name, states[i].area);
                    break;
                case 5:
                    printf("%s \t\t %d \n", states[i].name, states[i].sex_ratio);
                    break;
                case 6:
                    printf("%s \t\t %d \n", states[i].name, states[i].population);
                    break;
            }
        }
    } else if (input_type == 'c') {
        for ( i = 0; i < num_states-1; i++) {
            for ( j = 0; j < num_states-i-1; j++) {
                int swap = 0;
                switch (input_category) {
                    case 1:
                        swap = sort_order == 'a' ? strcmp(states[j].capital, states[j+1].capital) > 0 : strcmp(states[j].capital, states[j+1].capital) < 0;
                        break;
                    case 2:
                        swap = sort_order == 'a' ? strcmp(states[j].official_language, states[j+1].official_language) > 0 : strcmp(states[j].official_language, states[j+1].official_language) < 0;
                        break;
                    case 3:
                        swap = sort_order == 'a' ? states[j].literacy_rate > states[j+1].literacy_rate : states[j].literacy_rate < states[j+1].literacy_rate;
                        break;
                    case 4:
                        swap = sort_order == 'a' ? states[j].area > states[j+1].area : states[j].area < states[j+1].area;
                        break;
                    case 5:
                        swap = sort_order == 'a' ? states[j].sex_ratio > states[j+1].sex_ratio : states[j].sex_ratio < states[j+1].sex_ratio;
                        break;
                    case 6:
                        swap = sort_order == 'a' ? states[j].population > states[j+1].population : states[j].population < states[j+1].population;
                        break;
                }
                if (swap) {
                    struct state temp = states[j];
                    states[j] = states[j+1];
                    states[j+1] = temp;
                }
            }
        }
    }
}

