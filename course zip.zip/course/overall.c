#include <stdio.h>
#include <string.h>
struct state 
{
    char name[30];
    char capital[30];
    char official_language[40];
    int population;
    int area;
    int sex_ratio;
    float literacy_rate;
};
int main() 
{
	int i;
    FILE *file = fopen("p1.txt", "r");
    if (file == NULL) 
	{
        printf("Error opening file\n");
        return 1;
    }
    struct state states[28];
    int num_states = 0;
    while (fscanf(file, "%s %s %s %d %d %d %f", states[num_states].name, states[num_states].capital, states[num_states].official_language, &states[num_states].population, &states[num_states].area, &states[num_states].sex_ratio, &states[num_states].literacy_rate) == 7) 
	{
        num_states++;
    }
    fclose(file);
    char input_state[30];
    char input_category[30];
    printf("Enter state: ");
    scanf("%s", input_state);
    printf("Enter category: ");
    scanf("%s", input_category);
    for (i=0;i<num_states;i++) 
	{
        if (strcmp(states[i].name, input_state) == 0) 
		{
            if (strcmp(input_category, "capital") == 0)
			 {
                printf("%s\n", states[i].capital);
            }
			else if (strcmp(input_category, "official_language") == 0)
			{
				printf("%s\n", states[i].official_language);
			 } 
			else if (strcmp(input_category, "literacy_rate") == 0) 
			{
                printf("%.1f\n", states[i].literacy_rate);
            } 
			else if (strcmp(input_category, "area") == 0) 
			{
                printf("%d\n", states[i].area);
            } 
			else if (strcmp(input_category, "sex_ratio") == 0)
			 {
                printf("%d\n", states[i].sex_ratio);
            }
            else if (strcmp(input_category, "population") == 0)
            {
            	printf("%d\n", states[i].population);
			}
			else 
			{
                printf("Invalid category\n");
            }
            break;
        }
    }
    return 0;
}
